import {
  rotation,
  map,
  sizes,
  land,
  navigationHelper,
  scene,
  scenes,
  groundObject,
  camera,
  renderer,
} from "./globals";

import { generatingRoad, landGrow, isRoad } from "./functions";

function keydownListener(event) {
  if (event.keyCode == 38) {
    if (
      Math.abs(navigationHelper.placePicker.position.z - 1) <
      land.scale.y / 2
    ) {
      navigationHelper.placePicker.position.z -= 1;
    }
    console.log(
      "x= " +
        navigationHelper.placePicker.position.x +
        "z= " +
        navigationHelper.placePicker.position.z
    );
  }
  if (event.keyCode == 39) {
    if (
      Math.abs(navigationHelper.placePicker.position.x - -1) <
      land.scale.x / 2
    ) {
      navigationHelper.placePicker.position.x += 1;
    }
    console.log(
      "x=" +
        navigationHelper.placePicker.position.x +
        "z=" +
        navigationHelper.placePicker.position.z
    );
  }
  if (event.keyCode == 37) {
    if (
      Math.abs(navigationHelper.placePicker.position.x - 1) <
      land.scale.x / 2
    ) {
      navigationHelper.placePicker.position.x -= 1;
    }
    console.log(
      "x=" +
        navigationHelper.placePicker.position.x +
        "z=" +
        navigationHelper.placePicker.position.z
    );
  }
  if (event.keyCode == 40) {
    if (
      Math.abs(navigationHelper.placePicker.position.z - -1) <
      land.scale.y / 2
    ) {
      navigationHelper.placePicker.position.z += 1;
    }
    console.log(
      "x=" +
        navigationHelper.placePicker.position.x +
        "z=" +
        navigationHelper.placePicker.position.z
    );
  }
  if (event.keyCode == 51) {
    rotation += Math.PI / 2;
    navigationHelper.placePicker.rotation.z = rotation;
  }
  /* PANEL */
  if (event.keyCode == 49) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const panelCopy = scenes.panelScene.clone();
      panelCopy.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      panelCopy.rotation.y -= rotation;
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      scene.add(panelCopy);
      console.log("panel added");

      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //     drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /* ICE CREAM */
  if (event.keyCode == 50) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const iceCreamScene = scenes.iceCreamScene.clone();

      iceCreamScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      iceCreamScene.rotation.y -= rotation;
      scene.add(iceCreamScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("icecream added");

      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //      drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /* HOUSE */
  if (event.keyCode == 52) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const houseScene = scenes.houseScene.clone();

      houseScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      houseScene.rotation.y = -Math.PI / 2;
      houseScene.rotation.y -= rotation;
      scene.add(houseScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("house added");
      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //     drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*OFFICE */
  if (event.keyCode == 53) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const officeScene = scenes.officeScene.clone();

      officeScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      officeScene.rotation.y = -Math.PI / 2;
      officeScene.rotation.y -= rotation;
      scene.add(officeScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("house added");

      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //     drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*HAMBURGER */
  if (event.keyCode == 54) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const hamburgerScene = scenes.hamburgerScene.clone();

      hamburgerScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      hamburgerScene.rotation.y = -Math.PI / 2;
      hamburgerScene.rotation.y -= rotation;
      scene.add(hamburgerScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("house added");

      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //     drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*GROCERY */
  if (event.keyCode == 55) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const groceryScene = scenes.groceryScene.clone();

      groceryScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      groceryScene.rotation.y = -Math.PI / 2;
      groceryScene.rotation.y -= rotation;
      scene.add(groceryScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("house added");
      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //      drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*TOYSHOP */
  if (event.keyCode == 56) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const toyShopScene = scenes.toyShopScene.clone();

      toyShopScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      toyShopScene.rotation.y -= rotation;
      scene.add(toyShopScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("toyshop added");
      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //      drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*PLAYGROUND */
  if (event.keyCode == 57) {
    if (
      !map.has(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
      )
    ) {
      const playgroundScene = scenes.playgroundScene.clone();

      playgroundScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      playgroundScene.rotation.y -= rotation;
      scene.add(playgroundScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.building.house
      );
      console.log("toyshop added");
      generatingRoad(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
      //      drawingRoad();
      landGrow(
        navigationHelper.placePicker.position.x,
        navigationHelper.placePicker.position.z
      );
    }
  }
  /*CAR */
  if (event.keyCode == 67) {
    if (
      isRoad(
        map.get(
          `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`
        )
      )
    ) {
      // kellenek tovabbi feltetelek az utak iranyarol
      const carScene = scenes.carScene.clone();

      carScene.position.set(
        navigationHelper.placePicker.position.x,
        land.position.y,
        navigationHelper.placePicker.position.z
      );
      carScene.rotation.y = -Math.PI / 2;
      carScene.rotation.y -= rotation;
      scene.add(carScene);
      map.set(
        `${navigationHelper.placePicker.position.x}_${navigationHelper.placePicker.position.z}`,
        groundObject.vehicle.car
      );
      console.log("car added");
    }
  }
}

function resizeListener() {
  sizes.height = window.innerHeight;
  sizes.width = window.innerWidth;

  camera.aspect = sizes.width / sizes.height;
  camera.updateProjectionMatrix();

  renderer.setSize(sizes.width, sizes.height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
}

export { keydownListener, resizeListener };
